import gc
import time
from inputs import MidiSlider, BankButton
from midi import midi_manager
from settings import settings
from loopmanager import (LoopManager, SLOT_EMPTY, SLOT_RECORDING,
                         SLOT_PLAYING, SLOT_STOPPED)
from wiggle import SliderWiggleDetector
import constants as cfg

class MidiController:
    def __init__(self, slider_pins, button_pins):
        self.sliders = []
        self.buttons = []
        self.slider_pins = slider_pins
        self.button_pins = button_pins

        # Tracking
        self.current_page_idx = 0
        try:
            import microcontroller
            if hasattr(microcontroller, 'nvm'):
                saved_page = microcontroller.nvm[0]
                if 0 <= saved_page <= 3:
                    self.current_page_idx = saved_page
        except Exception:
            pass

        self.current_bank_idx = 0
        self.locked_bank_idx = 0
        self.primary_bank_idx = 0
        
        self.held_button_order = []
        self.additional_bank_indices = []
        self.has_anything_changed = False
        self.jump_mode_enabled = False
        self.unlock_pending = False
        self.page_just_changed = False
        
        # 自訂絕對防呆按鍵追蹤器 (無視底層 bug)
        self._raw_press_times = [0.0] * 4
        self._raw_button_states = [False] * 4
        self._raw_long_handled = [False] * 4
        
        # Double-press filter: ignore double-press on same button that was just unlocked
        self._last_unlocked_bank_idx = -1
        self._last_unlock_time = 0

        # Page change mode state
        self.page_change_mode_active = False  # True when in page change mode (hide all button colors)
        self.page_change_exit_button_idx = -1  # Button that must be released to exit page change mode
        self.page_limit_blink_idx = -1  # Button pixel to blink when at min/max
        self.page_limit_blink_time = 0  # When the blink started
        self.page_limit_blink_duration = 0.12  # Total on-off-on cycle duration (fast)
        self.page_limit_blink_locked = False  # If True, blink cycle is running and won't reset
        
        # Config mode: single click locks banks (for web config interface)
        self.config_mode = False

        # ==================== Record Mode state ====================
        self.record_mode_active = False
        self.record_mode_just_toggled = False  # code.py plays the enter/exit animation, then clears
        self.record_cc_set_idx = 0  # 0 = global bank, 1-4 = page 1 banks (separate from page/bank state)
        self.loop_manager = LoopManager()

        # Hold-all-four-buttons mode-toggle detection
        self._mode_hold_start = 0     # time.monotonic() when all four went down; 0 = not armed
        self._mode_hold_fired = False  # toggled already on this hold; waiting for releases

        # One-shot release suppression: a button's next release fires no gesture/slot
        # action (mode-toggle participants, set-navigation held button, etc.)
        self._suppress_release = [False] * 4

        # Per-slot click state machine (release-based; don't use
        # BankButton.was_double_pressed for click counting)
        self._slot_last_press_time = [0.0] * 4
        self._slot_pending_record = [False] * 4    # start recording on this button's next release
        self._slot_prev_play_state = [False] * 4   # play state at first press of a pair (delete restore)
        self._slot_ignore_press_until = [0.0] * 4  # swallow presses right after a stop-recording click

        # Delete arm/confirm state
        self._delete_armed_slot = -1
        self._delete_armed_time = 0.0
        self._delete_restore_play = False

        # Record-mode CC-set navigation (mirrors normal-mode page change)
        self._rec_nav_active = False
        self._rec_nav_exit_button_idx = -1

        # CC-set navigation flash: _set_flash_set_idx is the landed set,
        # flashed on its bank button in the page's color (global blanks all four)
        # for RECORD_SET_FLASH_S.
        self._set_flash_time = 0.0
        self._set_flash_set_idx = -1

        # Low-memory record-reject feedback: a refused record-start (free RAM
        # below START_RECORD_FLOOR) triple-blinks the pad red instead of
        # recording. -1 = no blink active.
        self._reject_blink_slot = -1
        self._reject_blink_start = 0.0

        # ==================== Mapping Mode state (on-device MIDI learn) ====================
        self.mapping_mode_active = False
        self.mapping_scope = None          # ("global",) or ("bank", page_idx, bank_idx)
        self.mapping_target_slider = -1    # -1 = no target selected (idle)
        self.mapping_confirm_until = 0.0   # confirm-flash deadline (0 = no flash)
        self.mapping_confirm_slider = -1   # which slider shows the confirm flash
        self.mapping_save_failed = False   # True -> red flash instead of green
        self._mapping_select_baseline = [0] * 4  # cc_value per slider at last (re)select/idle

        # Learn debounce: a single stray CC must not commit a mapping. Require
        # MAPPING_LEARN_HITS messages of the *same* (cc, channel) within
        # MAPPING_LEARN_WINDOW_S of each other - i.e. a sustained source stream
        # (twisting a knob), not a one-off.
        self._learn_candidate = None       # (cc_number, channel) being accumulated
        self._learn_count = 0
        self._learn_last_msg_time = 0.0

        # Deferred flash write: a committed mapping is applied live + lit green
        # immediately, and the blocking flash write runs one iteration later so
        # the green confirm frame renders before the write stalls the loop.
        self._mapping_pending_save = False

        # One wiggle detector per slider, shared by the global-entry,
        # bank-entry, and exit-wiggle contexts (only one context is armed
        # at a time).
        self._wiggle_detectors = [SliderWiggleDetector() for _ in range(4)]
        self._global_wiggle_armed = False

        # Bank-entry mapping context, captured at press-time
        self._bank_entry_armed = False
        self._bank_entry_page_idx = -1
        self._bank_entry_bank_idx = -1
        self._bank_entry_button_idx = -1

        # Setup
        self.setup_sliders()
        self.setup_buttons()
        self.setup_cc_banks()
        self.setup_channel_lookup()

    def setup_sliders(self):
        for idx, pin in enumerate(self.slider_pins):
            self.sliders.append(MidiSlider(pin, idx))

    def setup_buttons(self):
        for pin in self.button_pins:
            self.buttons.append(BankButton(pin))

    def update_inputs(self):
        """強制系統在按鈕壓著時保持運作，避免計時器失效"""
        slider_changes = [slider.update() for slider in self.sliders]
        button_changes = [button.update() for button in self.buttons]
        
        any_pressed = any(button.pressed for button in self.buttons)
        self.has_anything_changed = any(slider_changes + button_changes) or any_pressed
        
        return self.has_anything_changed
        
    def process_inputs(self):
        """Process input changes: bank/group changes, Jump Mode toggle, Record/Mapping Mode gestures."""
        # Record-mode machinery is time-based (hold timer, delete window,
        # playback pump) and must run every iteration, even with no input
        # changes.
        self.update_record_mode_state()

        # Mapping Mode machinery is likewise time-based (learn poll, blink
        # timing, confirm-flash expiry, wiggle windows) and entry-context
        # capture must see button presses before handle_lock_changes() can
        # act on them.
        self.update_mapping_mode_state()

        if not self.has_anything_changed:
            return

        # Consume one-shot release suppressions (mode-toggle hold and
        # set-navigation participants): these releases fire nothing in either mode.
        swallowed = [False] * 4
        for idx, button in enumerate(self.buttons):
            if button.detected_new_release and self._suppress_release[idx]:
                self._suppress_release[idx] = False
                swallowed[idx] = True

        if self.record_mode_active:
            self.process_record_mode_inputs(swallowed)
            return

        if self.mapping_mode_active:
            return

        self.handle_lock_changes()

        top_button = self.buttons[-1]
        middle_button_T = self.buttons[1]
        middle_button_B = self.buttons[2]
        bottom_button = self.buttons[0]

        top_hold_time = top_button.hold_time
        top_was_long_held = top_button.was_long_held
        top_new_release = top_button.detected_new_release and not swallowed[3]
        top_new_press = top_button.detected_new_press

        bottom_hold_time = bottom_button.hold_time
        bottom_was_long_held = bottom_button.was_long_held
        bottom_new_release = bottom_button.detected_new_release and not swallowed[0]
        bottom_new_press = bottom_button.detected_new_press
        
        # Check if middle buttons are held (prevents bank switch when multi-bank holding)
        middle_buttons_held = (middle_button_T.hold_time > 0) or (middle_button_B.hold_time > 0)
        
        # Check if ONLY the initiating button is held (for entering bank change mode)
        only_bottom_held = bottom_button.pressed and not any(b.pressed for b in [top_button, middle_button_T, middle_button_B])
        only_top_held = top_button.pressed and not any(b.pressed for b in [bottom_button, middle_button_T, middle_button_B])

        # Page switching logic:
        # - First switch uses release (to distinguish from multi-bank hold intent)
        # - Once in page change mode, use click for faster switching
        # - Only allow ENTERING page change mode if ONLY the initiating button is held
        # - While IN page change mode, no restrictions (works as before)
        
        # Switch to next page (bottom held, top activated)
        if bottom_hold_time > 0:
            if self.page_change_mode_active and top_new_press:
                # Already in page change mode - switch on click for rapid switching (no restrictions)
                self.next_page()
                self.unlock_bank()
                return
            elif not self.page_change_mode_active and top_new_release and not top_was_long_held and only_bottom_held:
                # Entering page change mode - only allow if ONLY bottom is held
                self.next_page()
                self.unlock_bank()
                return

        # Switch to previous page (top held, bottom activated)
        if top_hold_time > 0:
            if self.page_change_mode_active and bottom_new_press:
                # Already in page change mode - switch on click for rapid switching (no restrictions)
                self.previous_page()
                self.unlock_bank()
                return
            elif not self.page_change_mode_active and bottom_new_release and not bottom_was_long_held and only_top_held:
                # Entering page change mode - only allow if ONLY top is held
                self.previous_page()
                self.unlock_bank()
                return

        # Check for Jump Mode (requires BOTH middle buttons held)
        both_middle_buttons_held = (middle_button_T.hold_time > 0) and (middle_button_B.hold_time > 0)
        if both_middle_buttons_held:
            if top_new_release and not top_was_long_held:
                self.jump_mode_enabled = not self.jump_mode_enabled
                return  # Exit after toggling jump mode

            if bottom_new_release and not bottom_was_long_held:
                self.jump_mode_enabled = not self.jump_mode_enabled
                return  # Exit after toggling jump mode

        self.update_active_bank()

        # Mute sends during the standard-mode all-four-button countdown:
        # a global-entry wiggle attempt would otherwise spray full-range CC
        # values across the held multi-bank stack.
        if self._mode_hold_start != 0 and not self.record_mode_active:
            return

        self.send_cc_messages()

    def handle_lock_changes(self):
        """自建核彈級防呆狀態機：完全無視底層驅動，直接讀取物理訊號與絕對時間"""
        now = time.monotonic()
        
        # 處理 Page 導航模式的退出
        if self.page_change_mode_active and self.page_change_exit_button_idx != -1:
            exit_idx = self.page_change_exit_button_idx
            if not self.buttons[exit_idx].pressed:
                self.page_change_mode_active = False
                self.page_change_exit_button_idx = -1
                self.page_limit_blink_idx = -1
                self.page_limit_blink_locked = False
                # 攔截 Page 切換後的殘留放開事件
                self._raw_long_handled[exit_idx] = True
            return

        all_buttons_released = all(not button.pressed for button in self.buttons)
        if all_buttons_released:
            self.page_just_changed = False

        # 核心物理狀態追蹤
        for idx, button in enumerate(self.buttons):
            is_pressed = button.pressed
            was_pressed = self._raw_button_states[idx]
            
            if is_pressed and not was_pressed:
                # 剛按下的瞬間：開始計時
                self._raw_press_times[idx] = now
                self._raw_long_handled[idx] = False
                
            elif is_pressed and was_pressed:
                # 持續按壓中：檢查是否達到長按閾值 (0.5秒)
                if not self._raw_long_handled[idx]:
                    if (now - self._raw_press_times[idx]) >= cfg.LONG_HOLD_THRESH_S:
                        self._raw_long_handled[idx] = True  # 標記為長按已處理
                        if self.locked_bank_idx != idx:
                            self.lock_bank(idx)
                            
            elif not is_pressed and was_pressed:
                # 剛放開的瞬間：檢查是否為短按
                if not self._raw_long_handled[idx]:
                    # 確認放開時，沒有其他按鈕壓著 (避免組合鍵誤觸)
                    other_pressed = any(self._raw_button_states[i] for i in range(4) if i != idx)
                    if not other_pressed:
                        self.on_button_short_press(idx)
                        
            # 刷新歷史物理狀態
            self._raw_button_states[idx] = is_pressed

    def on_button_short_press(self, button_idx):
        """發送脈衝觸發訊號：動態切換 CC 或 Note"""
        # 1. 取得該按鈕的獨立數值 (CC 或 Note 號碼)
        button_val = settings.get_resolved_button_cc(self.current_page_idx, self.current_bank_idx, button_idx)
        
        # 2. 取得獨立 Channel
        channels = settings.get_resolved_button_channels(self.current_page_idx, self.current_bank_idx, button_idx)
        channel = channels[0] if channels else 0
        
        # 3. 取得設定的觸發型態，進行分流
        button_type = settings.get_resolved_button_type(self.current_page_idx, self.current_bank_idx, button_idx)
        
        if button_type == "Note":
            # 發送 Note On 然後秒送 Note Off 的脈衝
            midi_manager.send_note_pulse([channel], button_val, 127)
        else:
            # 發送 CC 脈衝
            midi_manager.send_cc([(button_val, channel)], 127)
            midi_manager.send_cc([(button_val, channel)], 0)

    def lock_bank(self, bank_idx):
        self.locked_bank_idx = bank_idx
        self.unlock_pending = False
        self.update_active_bank()

    def unlock_bank(self):
        """徹底廢除解鎖退回機制，只要放開按鍵，永遠停留在剛才長按的 Bank"""
        pass

    def update_active_bank(self):
        """強制狀態機跟隨 locked_bank_idx，隔絕任何退回 Global 的可能"""
        previous_bank_idx = self.current_bank_idx
        self.update_held_button_indices()

        # 絕對鎖定
        self.current_bank_idx = self.locked_bank_idx

        # Bank 若有改變才刷新推子
        if previous_bank_idx != self.current_bank_idx:
            self.update_slider_cc_assignments()

    def send_cc_messages(self):
        """完全依照 channel_lookup 派送 Fader 的 CC/AT 訊息（支援獨立指定通道）"""
        for slider_idx, slider in enumerate(self.sliders):
            if slider.cc_value_changed:
                # 從預先計算好的 channel_lookup 抓取該 Fader 解析後的通道列表
                channels = self.channel_lookup[self.current_page_idx][self.current_bank_idx][slider_idx]
                channel = channels[0] if channels else self.current_page_idx
                
                main_type = self.type_lookup[self.current_page_idx][self.current_bank_idx]

                if self.should_send_cc(slider, slider_idx, channel, main_type, self.current_bank_idx):
                    if main_type == "AT":
                        midi_manager.send_aftertouch([channel], slider.cc_value,
                                                      slider_idx, self.current_page_idx, self.current_bank_idx)
                    else:
                        midi_manager.send_cc([(slider.current_assigned_cc_number, channel)], slider.cc_value)

                slider.cc_value_changed = False

    def should_send_cc(self, slider, slider_idx, channel, message_type="CC", bank_idx=-1, page_idx=None):
        """Implement pickup mode: only send after physically crossing the last sent value."""
        cc_number = slider.current_assigned_cc_number
        cc_value = slider.cc_value
        if page_idx is None:
            page_idx = self.current_page_idx

        # Get last sent value based on message type
        # For AT, use per-slider tracking for independent pickup behavior
        if message_type == "AT":
            last_cc_sent = midi_manager.get_last_at_value_per_slider(slider_idx, page_idx, bank_idx)
        else:
            last_cc_sent = midi_manager.get_last_cc_value_sent(cc_number, channel)

        # Jump Mode always allows sending values immediately
        if self.jump_mode_enabled:
            return True
            
        # First-time initialization of crossing values
        if slider.crossing_cc_value == -1:
            slider.crossing_cc_value = cc_value
            slider.has_crossed_last_cc_value = False
            return False
            
        # Special handling for min/max edge values
        if last_cc_sent == cfg.MIN_CC_VALUE and cfg.MIN_CC_VALUE <= cc_value <= 2:
            slider.has_crossed_last_cc_value = True
            return True
            
        if last_cc_sent == cfg.MAX_CC_VALUE and 125 <= cc_value <= cfg.MAX_CC_VALUE:
            slider.has_crossed_last_cc_value = True
            return True
            
        # Once crossed threshold, continue sending all values
        if slider.has_crossed_last_cc_value:
            return True
            
        # Check if slider has crossed the last value from either direction
        crossed_from_above = cc_value < last_cc_sent < slider.crossing_cc_value
        crossed_from_below = cc_value > last_cc_sent > slider.crossing_cc_value
        
        if crossed_from_above or crossed_from_below:
            slider.has_crossed_last_cc_value = True
            return True
            
        # Skip small changes within the deadband
        if abs(cc_value - last_cc_sent) < cfg.CC_THRESHOLD:
            return False
            
        # Update tracking value for future comparisons
        slider.crossing_cc_value = cc_value
        return False

    def update_held_button_indices(self):
        """Track button press order. First is primary; empty list = global mode."""
        # Add newly pressed buttons to the end of the order list
        for idx, button in enumerate(self.buttons):
            if button.detected_new_press and idx not in self.held_button_order:
                self.held_button_order.append(idx)
        
        # Remove released buttons from the order list
        self.held_button_order = [idx for idx in self.held_button_order 
                                   if self.buttons[idx].pressed]
        
        # Derive primary and additional from the order list
        if self.held_button_order:
            self.primary_bank_idx = self.held_button_order[0]
            self.additional_bank_indices = self.held_button_order[1:]
        else:
            self.primary_bank_idx = -1
            self.additional_bank_indices = []
        
        return self.additional_bank_indices

    def update_active_bank(self):
        """Set active bank from lock or primary held button; update slider CC assignments if changed."""
        previous_bank_idx = self.current_bank_idx
        previous_additional_indices = list(self.additional_bank_indices)

        self.update_held_button_indices()

        if self.locked_bank_idx != -1:
            self.current_bank_idx = self.locked_bank_idx
        else:
            self.current_bank_idx = self.primary_bank_idx

        # Reassign CC numbers if we switched banks or changed held-button indices
        if (previous_bank_idx != self.current_bank_idx 
            or previous_additional_indices != self.additional_bank_indices):
            self.update_slider_cc_assignments()

    def update_slider_cc_assignments(self):
        """刷新推子 CC 並強制綁定 Page 通道"""
        current_cc_bank = self.pages[self.current_page_idx][self.current_bank_idx]

        for idx, slider in enumerate(self.sliders):
            slider.current_assigned_cc_number = current_cc_bank[idx]
            slider.additional_assigned_cc_numbers = []

            # 強制綁定 Page Channel
            current_channel = self.current_page_idx
            current_type = self.type_lookup[self.current_page_idx][self.current_bank_idx]

            if current_type == "AT":
                last_sent = midi_manager.get_last_at_value_per_slider(idx, self.current_page_idx, self.current_bank_idx)
            else:
                last_sent = midi_manager.get_last_cc_value_sent(slider.current_assigned_cc_number, current_channel)
            
            slider.crossing_cc_value = last_sent
            
            if abs(slider.cc_value - last_sent) <= cfg.CC_THRESHOLD:
                slider.has_crossed_last_cc_value = True
            else:
                slider.has_crossed_last_cc_value = False
            slider.cc_value_changed = False

    def setup_cc_banks(self):
        self.global_cc_bank = cfg.GLOBAL_CC_BANK

        self.pages = cfg.PAGES

        # Default global CC assignments
        for idx, slider in enumerate(self.sliders):
            slider.current_assigned_cc_number = self.global_cc_bank[idx]

    def setup_channel_lookup(self):
        """Precompute MIDI channel and message-type lookup tables for pages, banks, sliders."""
        self.global_channels = settings.get_global_channels()
        self.global_message_type = settings.get_global_message_type()

        # global_slider_channels[slider_idx] = list of 0-indexed channels
        self.global_slider_channels = [
            settings.get_resolved_global_slider_channels(slider)
            for slider in range(4)
        ]

        # channel_lookup[page_idx][bank_idx][slider_idx] = list of 0-indexed channels
        self.channel_lookup = [
            [
                [settings.get_resolved_slider_channels(page, bank, slider) for slider in range(4)]
                for bank in range(4)
            ]
            for page in range(4)
        ]

        # type_lookup[page_idx][bank_idx] = "CC" or "AT"
        self.type_lookup = [
            [settings.get_resolved_message_type(page, bank) for bank in range(4)]
            for page in range(4)
        ]

    def get_current_cc_bank(self):
        if self.current_bank_idx == -1:
            return self.global_cc_bank
        return self.pages[self.current_page_idx][self.current_bank_idx]

    def get_additional_cc_numbers(self, idx):
        additional_cc_numbers = []
        for button_idx in self.additional_bank_indices:
            bank = self.pages[self.current_page_idx][button_idx]
            additional_cc_numbers.append(bank[idx])
        return additional_cc_numbers

    def _save_page_to_nvm(self):
        """將當前 Page 寫入單晶片非揮發性記憶體，達成斷電記憶"""
        try:
            import microcontroller
            if hasattr(microcontroller, 'nvm'):
                if microcontroller.nvm[0] != self.current_page_idx:
                    microcontroller.nvm[0] = self.current_page_idx
        except Exception:
            pass

    def next_page(self):
        current_time = time.monotonic()
        new_idx = self.current_page_idx + 1
        
        self.page_change_mode_active = True
        self.page_change_exit_button_idx = 0
        self.page_just_changed = True
        
        if new_idx <= 3:
            self.current_page_idx = new_idx
            self.page_limit_blink_idx = -1
            self.page_limit_blink_locked = False
            
            # 寫入斷電記憶，並強制刷新推子的 Channel
            self._save_page_to_nvm()
            self.update_slider_cc_assignments()
        else:
            if not self.page_limit_blink_locked:
                self.page_limit_blink_idx = self.current_page_idx
                self.page_limit_blink_time = current_time
                self.page_limit_blink_locked = True

    def previous_page(self):
        current_time = time.monotonic()
        new_idx = self.current_page_idx - 1
        
        self.page_change_mode_active = True
        self.page_change_exit_button_idx = 3
        self.page_just_changed = True
        
        if new_idx >= 0:
            self.current_page_idx = new_idx
            self.page_limit_blink_idx = -1
            self.page_limit_blink_locked = False
            
            # 寫入斷電記憶，並強制刷新推子的 Channel
            self._save_page_to_nvm()
            self.update_slider_cc_assignments()
        else:
            if not self.page_limit_blink_locked:
                self.page_limit_blink_idx = self.current_page_idx
                self.page_limit_blink_time = current_time
                self.page_limit_blink_locked = True

    def update_page_change_feedback(self):
        """Return page-change-mode feedback: blink state, page indicator, limit blink."""
        current_time = time.monotonic()
        blink_button_idx = -1
        blink_off = False
        
        # Check if limit blink is active (on-off-on cycle)
        if self.page_limit_blink_idx != -1:
            elapsed = current_time - self.page_limit_blink_time
            if elapsed < self.page_limit_blink_duration:
                blink_button_idx = self.page_limit_blink_idx
                # Divide cycle into thirds: ON (0-33%), OFF (33-66%), ON (66-100%)
                cycle_position = elapsed / self.page_limit_blink_duration
                blink_off = (0.33 <= cycle_position < 0.66)
            else:
                # Blink cycle complete - unlock and clear
                self.page_limit_blink_idx = -1
                self.page_limit_blink_locked = False
        
        return {
            'page_change_mode': self.page_change_mode_active,
            'blink_button_idx': blink_button_idx,
            'blink_off': blink_off
        }

    def update_record_mode_state(self):
        """Run time-based Record Mode machinery: hold timer, delete window, caps, playback."""
        now = time.monotonic()

        # Web config mode and Record Mode are mutually exclusive
        if self.config_mode and self.record_mode_active:
            self._toggle_record_mode()

        self._update_mode_hold(now)

        if self.record_mode_active:
            self._update_delete_arm_timeout(now)
            # Hitting an event/memory/time cap auto-stops the recording
            # exactly like a manual stop.  Apply the same post-stop ignore
            # window as a manual stop so a click racing the cap can't pair
            # into a double-press and arm delete on the brand-new loop.
            auto_stopped = self.loop_manager.check_recording_limits()
            if auto_stopped >= 0:
                self._slot_ignore_press_until[auto_stopped] = now + cfg.DOUBLE_PRESS_TIME
                self._slot_last_press_time[auto_stopped] = 0.0
            # Hold-type loops are gate-played from the physical pad. Run before
            # process_loop_playback() so a just-pressed loop pumps this frame.
            self._update_hold_gate()
            self.process_loop_playback()

    def _update_hold_gate(self):
        """Gate playback for "hold"-type loops: a slot's loop plays only while
        its pad is physically held; releasing stops it (snapping back when
        cc_reset is on). Lives outside the click state machine because that
        machine's long-hold/swallow rules would eat a gate that the user holds
        past the long-hold threshold. The sweep still freezes on its final
        values at the end (looper._handle_loop_end) and stays parked until the
        pad is released.

        All loops share one global type (LOOP_TYPE), so this is inert when the
        device is in "loop" mode. Delete arming/confirm still runs through the
        click machine - while a slot is delete-armed the gate leaves it alone.
        """
        # The all-four hold is the Record Mode toggle gesture - don't let it
        # trigger every pad's gate at once.
        if all(button.pressed for button in self.buttons):
            return

        for slot_idx, button in enumerate(self.buttons):
            loop = self.loop_manager.loops[slot_idx]
            if loop is None or loop.is_recording or loop.loop_type != "hold":
                continue
            if not loop.has_events() or slot_idx == self._delete_armed_slot:
                continue

            if button.pressed:
                if not loop.loop_is_playing:
                    # toggle_playstate(True) resets to the top, so each new
                    # press restarts the sweep from the beginning.
                    self.loop_manager.toggle_playstate(slot_idx, True)
            elif loop.loop_is_playing:
                self._stop_loop_with_reset(slot_idx)

    def _update_mode_hold(self, now):
        """Detect the hold-all-four-buttons-for-3s Record Mode toggle."""
        if not all(button.pressed for button in self.buttons):
            self._disarm_global_wiggle()
            self._mode_hold_start = 0
            self._mode_hold_fired = False
            return

        if self.config_mode:
            # All-four hold is ignored while the web config is connected
            self._disarm_global_wiggle()
            self._mode_hold_start = 0
            return

        if self._mode_hold_fired:
            return  # Already toggled on this hold; waiting for the releases

        if self._mode_hold_start == 0:
            self._mode_hold_start = now
            # All four buttons participate in the hold: their releases must
            # not leak into either mode's gestures (suppression rule c) -
            # this also covers the jump-mode combo an aborted hold would match.
            for idx in range(4):
                self._suppress_release[idx] = True
            self._reset_slot_click_state()
            self._arm_global_wiggle_if_eligible(now)
        elif now - self._mode_hold_start >= cfg.RECORD_MODE_HOLD_S:
            self._mode_hold_fired = True
            self._disarm_global_wiggle()
            self._toggle_record_mode()

    def _arm_global_wiggle_if_eligible(self, now):
        """Arm the global-bank Mapping Mode entry context: only in
        standard mode, with no bank locked, not config_mode, and no other
        entry context already armed."""

        return  # <--- 【新增這行】強制結紮：永遠不武裝全域對應模式
    
        if (self.record_mode_active or self.config_mode or self.mapping_mode_active
                or self.locked_bank_idx != -1 or self._bank_entry_armed):
            return
        self._global_wiggle_armed = True
        for slider, detector in zip(self.sliders, self._wiggle_detectors):
            detector.arm(slider.cc_value, now)

    def _disarm_global_wiggle(self):
        if not self._global_wiggle_armed:
            return
        self._global_wiggle_armed = False
        for detector in self._wiggle_detectors:
            detector.disarm()

    @property
    def mode_hold_pixels_lit(self):
        """How many button pixels of red hold-progress fill to show (0-4)."""
        if self._mode_hold_start == 0 or self._mode_hold_fired:
            return 0
        elapsed = time.monotonic() - self._mode_hold_start
        pixels_lit = int(elapsed / cfg.RECORD_MODE_HOLD_STEP_S)
        return min(pixels_lit, 4)

    def _toggle_record_mode(self):
        if self.record_mode_active:
            self._exit_record_mode()
        else:
            self._enter_record_mode()
        self.record_mode_just_toggled = True

        # Hard-reset normal-mode gesture state so the trailing releases land
        # clean in the other mode
        self.unlock_bank()
        self.held_button_order = []
        self.primary_bank_idx = -1
        self.additional_bank_indices = []
        self.unlock_pending = False
        self.page_change_mode_active = False
        self.page_change_exit_button_idx = -1
        self.page_limit_blink_idx = -1
        self.page_limit_blink_locked = False
        self.page_just_changed = False

        # Reset record-mode gesture state
        self._reset_slot_click_state()
        self._rec_nav_active = False
        self._rec_nav_exit_button_idx = -1
        self._set_flash_set_idx = -1

    def _enter_record_mode(self):
        self.record_mode_active = True
        self.record_cc_set_idx = 0  # Start in global set
        self.loop_manager.set_active_set(0)
        self.update_record_slider_assignments()

    def _exit_record_mode(self):
        """Exit Record Mode: finalize recordings, cancel delete-arms, stop all loops."""
        self.record_mode_active = False

        if self.loop_manager.is_recording:
            self.loop_manager.stop_recording()

        self._cancel_delete_arm(restore=False)

        # Stop every loop in every set (they stay in RAM across record sessions).
        for loop in self.loop_manager.iter_all_loops():
            self._stop_loop_obj_with_reset(loop)

        # Normal-mode page/bank state was never touched; just
        # restore the sliders' normal CC assignments and pickup tracking.
        self.update_slider_cc_assignments()

    def _reset_slot_click_state(self):
        for idx in range(4):
            self._slot_last_press_time[idx] = 0.0
            self._slot_pending_record[idx] = False
            self._slot_prev_play_state[idx] = False
            self._slot_ignore_press_until[idx] = 0.0

    def process_record_mode_inputs(self, swallowed):
        """Record-mode gestures: all normal gestures inert except set navigation."""
        # Exit set-navigation mode when its initiating button is released
        # (mirrors page change mode)
        if self._rec_nav_active:
            if (self._rec_nav_exit_button_idx != -1
                    and not self.buttons[self._rec_nav_exit_button_idx].pressed):
                self._rec_nav_active = False
                self._rec_nav_exit_button_idx = -1

        if all(not button.pressed for button in self.buttons):
            self._rec_nav_active = False
            self._rec_nav_exit_button_idx = -1

        # While the all-four mode-toggle hold is in progress, slot actions are
        # inert but the faders keep sending (and recording)
        if all(button.pressed for button in self.buttons):
            self.send_record_mode_cc()
            return

        if self._handle_set_navigation(swallowed):
            return

        if not self._rec_nav_active:
            # In rapid-stepping navigation mode, clicks are navigation only
            self._process_slot_clicks(swallowed)
        self.send_record_mode_cc()

    def _handle_set_navigation(self, swallowed):
        """Step through CC sets with page-change gesture. Return True if consumed."""
        top_button = self.buttons[3]
        bottom_button = self.buttons[0]
        middles_idle = not self.buttons[1].pressed and not self.buttons[2].pressed
        only_bottom_held = bottom_button.pressed and not top_button.pressed and middles_idle
        only_top_held = top_button.pressed and not bottom_button.pressed and middles_idle

        # Next set (bottom held, top activated)
        if bottom_button.hold_time > 0:
            if self._rec_nav_active and top_button.detected_new_press:
                self._cancel_slot_click(3)
                self._step_record_set(1)
                return True
            if (not self._rec_nav_active and top_button.detected_new_release
                    and not swallowed[3] and not top_button.was_long_held
                    and only_bottom_held):
                self._rec_nav_active = True
                self._rec_nav_exit_button_idx = 0
                self._suppress_release[0] = True  # held button's release fires nothing (rule b)
                self._cancel_slot_click(0)
                self._cancel_slot_click(3)
                self._step_record_set(1)
                return True

        # Previous set (top held, bottom activated)
        if top_button.hold_time > 0:
            if self._rec_nav_active and bottom_button.detected_new_press:
                self._cancel_slot_click(0)
                self._step_record_set(-1)
                return True
            if (not self._rec_nav_active and bottom_button.detected_new_release
                    and not swallowed[0] and not bottom_button.was_long_held
                    and only_top_held):
                self._rec_nav_active = True
                self._rec_nav_exit_button_idx = 3
                self._suppress_release[3] = True
                self._cancel_slot_click(0)
                self._cancel_slot_click(3)
                self._step_record_set(-1)
                return True

        return False

    def _cancel_slot_click(self, slot_idx):
        """Clear pending click state for a slot (button used by another gesture)."""
        self._slot_last_press_time[slot_idx] = 0.0
        self._slot_pending_record[slot_idx] = False

    def _step_record_set(self, direction):
        new_idx = self.record_cc_set_idx + direction
        # No wrap; clamp at ends
        if new_idx < 0 or new_idx >= cfg.NUM_RECORD_CC_SETS:
            return
        self._cancel_delete_arm(restore=True)
        # Finalize any in-flight recording as a single-click-stop before leaving
        # the bank: otherwise send_record_mode_cc would keep taping the
        # recording loop with the NEW bank's CC assignments, corrupting it.
        if self.loop_manager.is_recording:
            self.loop_manager.stop_recording()
        # Stop "hold" loops in the bank we're leaving - their pads are no longer
        # addressable from another bank. "loop" loops keep playing.
        self._stop_hold_loops_in_active_set()

        self.record_cc_set_idx = new_idx
        self.loop_manager.set_active_set(new_idx)  # slot ops now address this set's 4 pads
        self.update_record_slider_assignments()

        # Navigation flash: the lights light the landed set's bank button in the
        # page's color (the global set blanks all four). Button position encodes
        # the bank, color encodes the page, so going up lands on bank 1 (bottom)
        # and walks up, going down lands on bank 4 (top) and walks down.
        self._set_flash_set_idx = self.record_cc_set_idx
        self._set_flash_time = time.monotonic()

    def _record_set_lookup(self, slider_idx):
        """Resolve active record CC set. Returns (cc_number, channels, message_type, bank_idx, page_idx)."""
        set_idx = self.record_cc_set_idx
        if set_idx == 0:
            return (cfg.GLOBAL_CC_BANK[slider_idx],
                    self.global_slider_channels[slider_idx],
                    self.global_message_type,
                    -1, 0)
        page_idx = (set_idx - 1) // 4
        bank_idx = (set_idx - 1) % 4
        return (self.pages[page_idx][bank_idx][slider_idx],
                self.channel_lookup[page_idx][bank_idx][slider_idx],
                self.type_lookup[page_idx][bank_idx],
                bank_idx, page_idx)

    def update_record_slider_assignments(self):
        """Record-mode CC assignment: assign from active set, reset pickup tracking."""
        for idx, slider in enumerate(self.sliders):
            cc_number, channels, message_type, bank_idx, page_idx = self._record_set_lookup(idx)
            slider.current_assigned_cc_number = cc_number
            slider.additional_assigned_cc_numbers = []

            if message_type == "AT":
                last_sent = midi_manager.get_last_at_value_per_slider(idx, page_idx, bank_idx)
            else:
                last_sent = midi_manager.get_last_cc_value_sent(cc_number, channels[0])
            slider.crossing_cc_value = last_sent

            if abs(slider.cc_value - last_sent) <= cfg.CC_THRESHOLD:
                slider.has_crossed_last_cc_value = True
            else:
                slider.has_crossed_last_cc_value = False
            slider.cc_value_changed = False

    def _process_slot_clicks(self, swallowed):
        now = time.monotonic()
        for idx, button in enumerate(self.buttons):
            if button.detected_new_press:
                self._handle_slot_press(idx, now)
        for idx, button in enumerate(self.buttons):
            if button.detected_new_release:
                self._handle_slot_release(idx, button, swallowed[idx], now)

    def _handle_slot_press(self, slot_idx, now):
        # Presses within the double-press window after a stop-recording click
        # are ignored - otherwise a bouncy stop click would arm delete on the
        # brand-new loop
        if now < self._slot_ignore_press_until[slot_idx]:
            self._suppress_release[slot_idx] = True
            self._slot_last_press_time[slot_idx] = 0.0
            return

        # Confirm delete: an explicit press on the armed slot within the window
        if self._delete_armed_slot == slot_idx:
            self._confirm_delete(slot_idx)
            self._suppress_release[slot_idx] = True
            self._slot_last_press_time[slot_idx] = 0.0
            return

        # Any other slot's action cancels an armed delete (restores play
        # state); this press is then processed normally
        if self._delete_armed_slot != -1:
            self._cancel_delete_arm(restore=True)

        is_double = (self._slot_last_press_time[slot_idx] > 0
                     and (now - self._slot_last_press_time[slot_idx]) <= cfg.DOUBLE_PRESS_TIME)
        self._slot_last_press_time[slot_idx] = now

        if not is_double:
            # First press of a potential pair: capture the play state for a
            # possible delete-arm restore (before the first click toggles it)
            loop = self.loop_manager.loops[slot_idx]
            self._slot_prev_play_state[slot_idx] = bool(loop and loop.loop_is_playing)
            return

        # --- Double-press recognized (on the second press) ---
        state = self.loop_manager.get_slot_state(slot_idx)
        if state == SLOT_EMPTY:
            # Start recording fires on the second release
            self._slot_pending_record[slot_idx] = True
        elif state in (SLOT_PLAYING, SLOT_STOPPED):
            self._arm_delete(slot_idx, now)
            self._suppress_release[slot_idx] = True  # second release fires nothing

    def _handle_slot_release(self, slot_idx, button, was_swallowed, now):
        # Suppression rules: (c) mode-toggle/navigation participants...
        if was_swallowed:
            self._slot_pending_record[slot_idx] = False
            self._slot_last_press_time[slot_idx] = 0.0
            return
        # ...and (a) long-held buttons
        if button.was_long_held:
            self._slot_pending_record[slot_idx] = False
            self._slot_last_press_time[slot_idx] = 0.0
            return

        if self._slot_pending_record[slot_idx]:
            self._slot_pending_record[slot_idx] = False
            # Switching from another recording slot finalizes that recording
            # first (inside LoopManager.start_recording). start_recording returns
            # False if it refused for low memory - the pad triple-blinks instead
            # of recording (the slot stays empty).
            if not self.loop_manager.start_recording(slot_idx, self.record_cc_set_idx):
                self._trigger_reject_blink(slot_idx, now)
                self._slot_last_press_time[slot_idx] = 0.0
                return
            # Re-arm pickup on every record start: a slider that
            # already "crossed" in a prior interaction would otherwise send (and
            # record) from its current position immediately - i.e. behave like
            # jump mode. After re-arming, a drifted slider must move past its
            # last-sent value before it records; that pre-pickup motion is not
            # captured (the record tap in send_record_mode_cc runs only after
            # should_send_cc passes) and Trim Silence drops it as lead-in.
            # Jump Mode still short-circuits should_send_cc, so it's unaffected.
            self.update_record_slider_assignments()
            # Ignore presses within the double-press window after starting a
            # recording (symmetric with stop-recording) - prevents a bouncy
            # third tap from immediately single-click stopping the new recording.
            self._slot_ignore_press_until[slot_idx] = now + cfg.DOUBLE_PRESS_TIME
            self._slot_last_press_time[slot_idx] = 0.0
            return

        # --- Single-click actions ---
        state = self.loop_manager.get_slot_state(slot_idx)
        if state == SLOT_RECORDING:
            self.loop_manager.stop_recording()
            self._slot_ignore_press_until[slot_idx] = now + cfg.DOUBLE_PRESS_TIME
            self._slot_last_press_time[slot_idx] = 0.0
            return

        # Hold-type loops are gate-played by _update_hold_gate (pad down = play,
        # pad up = stop). Single clicks never start/stop their playback - the
        # click machine only records and deletes them.
        loop = self.loop_manager.loops[slot_idx]
        if loop is not None and loop.loop_type == "hold":
            return

        if state == SLOT_PLAYING:
            self._stop_loop_with_reset(slot_idx)
        elif state == SLOT_STOPPED:
            self.loop_manager.toggle_playstate(slot_idx, True)
        # SLOT_EMPTY: no-op

    def _arm_delete(self, slot_idx, now):
        self._delete_armed_slot = slot_idx
        self._delete_armed_time = now
        # Restore target is the play state from before the first click of the
        # pair (the first click's release already toggled it - accepted transient)
        self._delete_restore_play = self._slot_prev_play_state[slot_idx]

        loop = self.loop_manager.loops[slot_idx]
        if loop is not None and loop.loop_is_playing:
            self._stop_loop_with_reset(slot_idx)

    def _cancel_delete_arm(self, restore=True):
        if self._delete_armed_slot == -1:
            return
        slot_idx = self._delete_armed_slot
        self._delete_armed_slot = -1
        if restore and self._delete_restore_play and self.loop_manager.slot_has_loop(slot_idx):
            self.loop_manager.toggle_playstate(slot_idx, True)

    def _confirm_delete(self, slot_idx):
        self._delete_armed_slot = -1
        self.loop_manager.delete_loop(slot_idx)

    def _update_delete_arm_timeout(self, now):
        if (self._delete_armed_slot != -1
                and now - self._delete_armed_time > cfg.DELETE_CONFIRM_WINDOW_S):
            self._cancel_delete_arm(restore=True)

    def send_record_mode_cc(self):
        """Record-mode fader output: live send + recording tap to active set."""
        recording_loop = self.loop_manager.get_recording_loop()

        for slider_idx, slider in enumerate(self.sliders):
            if not slider.cc_value_changed:
                continue

            cc_number, channels, message_type, bank_idx, page_idx = self._record_set_lookup(slider_idx)

            if not self.should_send_cc(slider, slider_idx, channels[0], message_type,
                                       bank_idx, page_idx=page_idx):
                continue

            value = slider.cc_value
            if message_type == "AT":
                midi_manager.send_aftertouch(channels, value, slider_idx, page_idx, bank_idx)
                if recording_loop is not None:
                    for channel in channels:
                        recording_loop.add_aftertouch(value, channel)
            else:
                midi_manager.send_cc([(cc_number, ch) for ch in channels], value)
                if recording_loop is not None:
                    for channel in channels:
                        recording_loop.add_cc(cc_number, value, channel)

            slider.cc_value_changed = False

    def process_loop_playback(self):
        """Playback pump: collect and send due events from all loops in all sets."""
        for loop in self.loop_manager.iter_all_loops():
            events = loop.get_new_events()
            if not events:
                continue
            new_cc, new_at = events
            for cc_number, value, channel in new_cc:
                midi_manager.send_cc([(cc_number, channel)], value)
            for _, pressure, channel in new_at:
                midi_manager.send_aftertouch([channel], pressure)

    def _stop_loop_with_reset(self, slot_idx):
        """Stop slot's loop; if cc_reset enabled, snap to first values."""
        self._stop_loop_obj_with_reset(self.loop_manager.loops[slot_idx])

    def _stop_loop_obj_with_reset(self, loop):
        """Stop loop with cc_reset snap-back (any set, any context)."""
        if loop is None or loop.is_recording:
            return
        was_playing = loop.loop_is_playing
        loop.toggle_playstate(False)
        if was_playing and settings.get_cc_reset():
            self._send_cc_reset(loop)

    def _stop_hold_loops_in_active_set(self):
        """Stop playing 'hold' loops in active set (leave 'loop' loops running)."""
        for loop in self.loop_manager.loops:
            if loop is not None and loop.loop_type == "hold" and loop.loop_is_playing:
                self._stop_loop_obj_with_reset(loop)

    def _send_cc_reset(self, loop):
        for (cc_number, channel), first_value in loop._first_cc_values.items():
            midi_manager.send_cc([(cc_number, channel)], first_value)
        for channel, first_pressure in loop._first_at_values.items():
            midi_manager.send_aftertouch([channel], first_pressure)

    def get_record_slot_states(self):
        """Per-slot display state for LightsManager: empty/recording/playing/stopped/delete_armed."""
        states = []
        for slot_idx in range(4):
            if slot_idx == self._delete_armed_slot:
                states.append("delete_armed")
            else:
                states.append(self.loop_manager.get_slot_state(slot_idx))
        return states

    def get_set_flash(self):
        """Return CC-set navigation flash index, or -1 if none."""
        if self._set_flash_set_idx == -1:
            return -1
        if time.monotonic() - self._set_flash_time > cfg.RECORD_SET_FLASH_S:
            self._set_flash_set_idx = -1
            return -1
        return self._set_flash_set_idx

    def _trigger_reject_blink(self, slot_idx, now):
        """Start/restart low-memory reject blink. Idempotent."""
        self._reject_blink_slot = slot_idx
        self._reject_blink_start = now

    def get_reject_blink(self):
        """Return (slot_idx, on) for low-memory reject blink feedback, or (-1, False)."""
        if self._reject_blink_slot == -1:
            return (-1, False)
        elapsed = time.monotonic() - self._reject_blink_start
        if elapsed >= cfg.RECORD_REJECT_BLINK_S * 6:  # 3 on + 3 off
            self._reject_blink_slot = -1
            return (-1, False)
        on = int(elapsed / cfg.RECORD_REJECT_BLINK_S) % 2 == 0
        return (self._reject_blink_slot, on)

    @property
    def record_display_bank_idx(self):
        """Active record set mapped to a bank index for the slider lights;
        -1 = global."""
        if self.record_cc_set_idx == 0:
            return -1
        return (self.record_cc_set_idx - 1) % 4

    @property
    def record_display_page_idx(self):
        """Page index the active record set lives on (0 for the global set)."""
        if self.record_cc_set_idx == 0:
            return 0
        return (self.record_cc_set_idx - 1) // 4

    # ==================== Mapping Mode (on-device MIDI learn) ====================

    @property
    def mapping_bank_button_idx(self):
        """Bank-scope: button index to keep lit; global scope: -1."""
        if self.mapping_scope is not None and self.mapping_scope[0] == "bank":
            return self.mapping_scope[2]
        return -1

    @property
    def mapping_bank_page_idx(self):
        """Bank-scope: page index for button color; global scope: 0."""
        if self.mapping_scope is not None and self.mapping_scope[0] == "bank":
            return self.mapping_scope[1]
        return 0

    def update_mapping_mode_state(self):
        """Run time-based Mapping Mode machinery: wiggle detection, learn poll, confirm/cancel."""
        now = time.monotonic()

        # Record Mode and web config are mutually exclusive with Mapping Mode.
        if self.mapping_mode_active and (self.config_mode or self.record_mode_active):
            self._exit_mapping_mode()
            return

        self._update_bank_entry_wiggle(now)

        if self.mapping_mode_active:
            self._update_mapping_mode_active(now)
            return

        if self._global_wiggle_armed or self._bank_entry_armed:
            self._poll_wiggle_detectors(now)

    def _update_bank_entry_wiggle(self, now):
        """Capture/maintain bank-entry Mapping Mode context: arm on press, disarm on release."""

        return  # <--- 【新增這行】強制結紮：永遠不武裝單頁對應模式
    
        if self._bank_entry_armed:
            if not self.buttons[self._bank_entry_button_idx].pressed:
                self._bank_entry_armed = False
                for detector in self._wiggle_detectors:
                    detector.disarm()
            return

        if self.record_mode_active or self.config_mode or self.mapping_mode_active:
            return

        if self.locked_bank_idx == -1:
            return

        for idx, button in enumerate(self.buttons):
            if idx == self.locked_bank_idx and button.detected_new_press:
                self._bank_entry_armed = True
                self._bank_entry_page_idx = self.current_page_idx
                self._bank_entry_bank_idx = idx
                self._bank_entry_button_idx = idx
                for slider, detector in zip(self.sliders, self._wiggle_detectors):
                    detector.arm(slider.cc_value, now)
                break

    def _poll_wiggle_detectors(self, now):
        """Feed slider samples to wiggle detectors; act on first completion."""
        for idx, (slider, detector) in enumerate(zip(self.sliders, self._wiggle_detectors)):
            if detector.update(slider.cc_value, now):
                self._on_wiggle_complete(idx)
                return

    def _on_wiggle_complete(self, slider_idx):
        """Wiggle completed on slider_idx. AT-type scopes block entry."""
        if self._global_wiggle_armed:
            if settings.get_global_message_type() == "AT":
                self._wiggle_detectors[slider_idx].disarm()
                return
            self._disarm_global_wiggle()
            self._mode_hold_fired = True
            self._enter_mapping_mode(slider_idx, ("global",))
            return

        if self._bank_entry_armed:
            page_idx = self._bank_entry_page_idx
            bank_idx = self._bank_entry_bank_idx
            if self.type_lookup[page_idx][bank_idx] == "AT":
                self._wiggle_detectors[slider_idx].disarm()
                return
            button_idx = self._bank_entry_button_idx
            self._bank_entry_armed = False
            for detector in self._wiggle_detectors:
                detector.disarm()
            self._suppress_release[button_idx] = True
            self._enter_mapping_mode(slider_idx, ("bank", page_idx, bank_idx))

    def _enter_mapping_mode(self, slider_idx, scope):
        """Enter Mapping Mode. scope = ("global",) or ("bank", page_idx, bank_idx)."""
        self.mapping_mode_active = True
        self.mapping_scope = scope
        self.mapping_target_slider = slider_idx
        self.mapping_confirm_until = 0.0
        self.mapping_confirm_slider = -1
        self.mapping_save_failed = False
        self._reset_learn_accumulator()
        self._mapping_pending_save = False

        # Hard output kill-switch: the device must NEVER emit MIDI while
        # learning, or its own output could feed back in and self-map.
        midi_manager.output_muted = True
        midi_manager.flush_receive_buffer()

        now = time.monotonic()
        for idx, slider in enumerate(self.sliders):
            self._mapping_select_baseline[idx] = slider.cc_value
            self._wiggle_detectors[idx].arm(slider.cc_value, now)

        # Hard-reset normal-mode gesture state so stale presses/releases can't
        # fire once Mapping Mode exits (mirrors _toggle_record_mode).
        self.held_button_order = []
        self.primary_bank_idx = -1
        self.additional_bank_indices = []
        self.unlock_pending = False
        self.page_change_mode_active = False
        self.page_change_exit_button_idx = -1
        self.page_limit_blink_idx = -1
        self.page_limit_blink_locked = False
        self.page_just_changed = False

    def _update_mapping_mode_active(self, now):
        """Per-iteration logic: deferred flash write, confirm expiry, cancel, exit wiggle, retarget, learn poll."""
        # Deferred flash write: _apply_mapping applied the mapping live and lit
        # the green flash last iteration, so that green frame has already
        # rendered. Do the blocking write now; downgrade to red on failure, and
        # restart the confirm timer from write-completion so the result stays
        # visible for the full interval even if the write outran it.
        if self._mapping_pending_save:
            self._mapping_pending_save = False
            if not settings.save():
                self.mapping_save_failed = True
            self.mapping_confirm_until = time.monotonic() + cfg.MAPPING_CONFIRM_S

        if self.mapping_confirm_slider != -1 and now >= self.mapping_confirm_until:
            self.mapping_confirm_slider = -1
            self.mapping_confirm_until = 0.0
            self.mapping_save_failed = False

        # Cancel button: any new press exits immediately.
        for idx, button in enumerate(self.buttons):
            if button.detected_new_press:
                self._suppress_release[idx] = True
                self._exit_mapping_mode()
                return

        # Exit wiggle
        for idx, (slider, detector) in enumerate(zip(self.sliders, self._wiggle_detectors)):
            if detector.update(slider.cc_value, now):
                self._exit_mapping_mode()
                return

        # Retarget: the first slider that moved far enough from its
        # baseline becomes the new target.
        for idx, slider in enumerate(self.sliders):
            if abs(slider.cc_value - self._mapping_select_baseline[idx]) >= cfg.MAPPING_SELECT_DELTA:
                self._retarget_mapping(idx)
                break

        # Learn poll: drain one incoming CC per iteration regardless of
        # whether a target is selected. A mapping only commits once
        # MAPPING_LEARN_HITS messages of the same (cc, channel) arrive within
        # MAPPING_LEARN_WINDOW_S of each other, so a single stray CC can't map.
        msg = midi_manager.receive_cc()
        if msg is not None and self.mapping_target_slider != -1:
            cc_number, channel = msg
            if (self._learn_candidate == (cc_number, channel)
                    and now - self._learn_last_msg_time <= cfg.MAPPING_LEARN_WINDOW_S):
                self._learn_count += 1
            else:
                self._learn_candidate = (cc_number, channel)
                self._learn_count = 1
            self._learn_last_msg_time = now
            if self._learn_count >= cfg.MAPPING_LEARN_HITS:
                self._apply_mapping(self.mapping_target_slider, cc_number, channel)
                midi_manager.flush_receive_buffer()

    def _reset_learn_accumulator(self):
        """Clear learn-debounce state (no carry across target change or commit)."""
        self._learn_candidate = None
        self._learn_count = 0
        self._learn_last_msg_time = 0.0

    def _retarget_mapping(self, slider_idx):
        """Retarget learn to slider_idx; re-baseline and flush stale MIDI."""
        self.mapping_target_slider = slider_idx
        for idx, slider in enumerate(self.sliders):
            self._mapping_select_baseline[idx] = slider.cc_value
        self._reset_learn_accumulator()
        midi_manager.flush_receive_buffer()

    def _apply_mapping(self, slider_idx, cc_number, channel):
        """Commit learn: apply live + green flash; defer write to next iteration."""
        scope = self.mapping_scope
        if scope[0] == "global":
            applied = settings.set_global_slider_mapping(slider_idx, cc_number, channel, persist=False)
        else:
            _, page_idx, bank_idx = scope
            applied = settings.set_bank_slider_mapping(page_idx, bank_idx, slider_idx, cc_number, channel, persist=False)

        # CC numbers propagate via aliasing; channels are
        # precomputed copies and need an explicit rebuild.
        self.setup_channel_lookup()
        gc.collect()

        # Optimistic green now; the deferred write flips it to red on failure.
        self.mapping_save_failed = not applied
        self.mapping_confirm_slider = slider_idx
        self.mapping_confirm_until = time.monotonic() + cfg.MAPPING_CONFIRM_S
        self.mapping_target_slider = -1
        self._reset_learn_accumulator()
        self._mapping_pending_save = applied  # only persist a live-applied map

    def _exit_mapping_mode(self):
        """Exit Mapping Mode: clear state, re-lock bank, refresh slider CC and pickup."""
        scope = self.mapping_scope

        # If a learn was applied live but its deferred flash write hadn't run
        # yet (e.g. config/record mode preempted Mapping Mode in the one
        # iteration between commit and the write), persist it now so the
        # mapping survives a reboot.
        if self._mapping_pending_save:
            self._mapping_pending_save = False
            settings.save()

        self.mapping_mode_active = False
        self.mapping_scope = None
        self.mapping_target_slider = -1
        self.mapping_confirm_until = 0.0
        self.mapping_confirm_slider = -1
        self.mapping_save_failed = False
        self._bank_entry_armed = False
        self._reset_learn_accumulator()

        # Lift the output kill-switch now that learning is over (normal sends
        # resume on the next fader move).
        midi_manager.output_muted = False

        for detector in self._wiggle_detectors:
            detector.disarm()

        if scope is not None and scope[0] == "bank":
            bank_idx = scope[2]
            self.lock_bank(bank_idx)
        else:
            self.held_button_order = []
            self.primary_bank_idx = -1
            self.additional_bank_indices = []
            self.update_active_bank()

        self.update_slider_cc_assignments()